const BaseConfig = {
  accessKey: 'aHE6IX8tZ2EJOn5u3ZMEFDU7aj5U3-QRqLEmAnQr',
  secretKey: 'WJM7X5Pc9bYeOaKgiT66qFuMU5H_kRJEgRlDeXqa',
  bucket: 'renren',
  domain: 'http://cdn.yuanfangzixun.com.cn',
  bomQrCode_url: 'http://admin.yuanfangzixun.com.cn/workSubmit.html'
}

module.exports = BaseConfig