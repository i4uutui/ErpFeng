const express = require('express');
const router = express.Router();
const { Op, SubDateInfo, SubApprovalUser, SubProductNotice, SubProductionProgress, SubSaleOrder, SubWarehouseApply } = require('../models')
const authMiddleware = require('../middleware/auth');
const { PreciseMath } = require('../middleware/tool');

/**
 * @swagger
 * /admin/special-dates:
 *   get:
 *     summary: 获取所有特殊日期
 *     tags:
 *       - 首页接口(Home)
 */
router.get('/special-dates', authMiddleware, async (req, res) => {
  const { company_id } = req.user;

  const dates = await SubDateInfo.findAll({
    where: { company_id },
    attributes: ['id', 'date'],
    order: [['date', 'ASC']]
  });
  
  // 转换为前端需要的格式
  const formattedDates = dates.map(date => ({
    id: date.id,
    date: date.date
  }));
  
  res.json({ data: formattedDates, code: 200 });
})

/**
 * @swagger
 * /admin/special-dates:
 *   post:
 *     summary: 日历保存日期
 *     tags:
 *       - 首页接口(Home)
 *     parameters:
 *       - name: dates
 *         schema:
 *           type: Array
 */
router.post('/special-dates', authMiddleware, async (req, res) => {
  const { dates } = req.body;
  const { company_id } = req.user;
  
  if (!dates || !Array.isArray(dates)) return res.json({ code: 401, message: '请选择日期' });

  const result = await SubDateInfo.findAll({
    where: { company_id },
  });
  // 先删除现有
  if(result.length){
    await SubDateInfo.destroy({ where: { company_id } });
  }
  // 再添加新的
  const data = dates.map(item => ({ date: item.date, company_id }))
  await SubDateInfo.bulkCreate(data, {
    updateOnDuplicate: ['date', 'company_id']
  });

  res.json({ msg: '添加成功', code: 200 });
})

/**
 * @swagger
 * /admin/statistics:
 *   get:
 *     summary: 待办事项
 *     tags:
 *       - 首页接口(Home)
 */
router.get('/statistics', authMiddleware, async (req, res) => {
  const { id: userId, company_id, type } = req.user;

  const where = {
    company_id, 
    status: 0,
  }
  if(type == 2) where.user_id = userId
  const result = await SubApprovalUser.findAll({ where })
  const data = result.map(o => o.toJSON())

  const materialMent = data.filter(o => o.type == 'purchase_order').length
  const outsourcingOrder = data.filter(o => o.type == 'outsourcing_order').length
  const materialOrder = data.filter(o => o.type == 'material_warehouse').length
  const productOrder = data.filter(o => o.type == 'product_warehouse').length

  res.json({ data: { materialMent, outsourcingOrder, materialOrder, productOrder }, code: 200 })
})

/**
 * @swagger
 * /admin/order_total:
 *   get:
 *     summary: 订单统计
 *     tags:
 *       - 首页接口(Home)
 */
router.get('/order_total', authMiddleware, async (req, res) => {
  const { company_id } = req.user;
  const created_at = req.query['created_at[]']

  try {
    const result = await SubProductNotice.findAll({
      where: {
        company_id,
        is_notice: 0, // 已排产
        is_deleted: 1, // 未删除
      },
      attributes: ['id', 'is_finish']
    })
    let onlineOrder = 0
    let finishOrder = 0
    let orderNumber = 0
    result.forEach(e => {
      const item = e.toJSON()
      if (item.is_finish === 1) {
        onlineOrder++
      } else {
        finishOrder++;
      }
    })
    const progress = await SubProductionProgress.findAll({
      where: {
        is_finish: 1,
        company_id
      },
      attributes: ['id', 'order_number', 'is_finish', 'order_number'],
      include: [
        {
          model: SubProductNotice,
          as: 'notice',
          attributes: ['id', 'sale_id'],
          include: [
            { model: SubSaleOrder, as: 'sale', attributes: ['id'] }
          ]
        }
      ]
    })
    const sumOrder = progress.reduce((sum, item) => PreciseMath.add(sum, Number(item.order_number)), 0);
    const resultProgress = progress.map(e => {
      const item = e.toJSON()
      return item.notice.sale.id
    })
    const apply = await SubWarehouseApply.findAll({
      where: {
        sale_id: resultProgress,
        company_id,
        type: 14
      },
      attributes: ['id', 'quantity']
    })
    const outOrder = apply.reduce((sum, item) => PreciseMath.add(sum, Number(item.quantity)), 0)
    orderNumber = PreciseMath.sub(sumOrder, outOrder)

    res.json({ code: 200, data: { onlineOrder, finishOrder, orderNumber } })
  } catch (error) {
    console.log(error);
  }
})
module.exports = router;