const express = require('express');
const router = express.Router();
const { SubMaterialBom, SubMaterialCode, SubMaterialBomChild, SubPartCode, SubProductCode, SubProcessBom, SubProcessBomChild, SubProcessCode, SubEquipmentCode, SubProcessCycle, Op, col } = require('../models');
const authMiddleware = require('../middleware/auth');
const { formatArrayTime, formatObjectTime } = require('../middleware/formatTime');
const MainDataService = require('../middleware/qrcodeService');
const BaseConfig = require('../config/BaseConfig')

// 获取材料BOM信息表
router.get('/material_bom', authMiddleware, async (req, res) => {
  const { page = 1, pageSize = 10, archive, product_code, product_name, drawing } = req.query;
  const offset = (page - 1) * pageSize;
  const { company_id } = req.user;
  
  const whereObj = {}
  if(product_code) whereObj.product_code = { [Op.like]: `%${product_code}%` }
  if(product_name) whereObj.product_name = { [Op.like]: `%${product_name}%` }
  if(drawing) whereObj.drawing = { [Op.like]: `%${drawing}%` }
  const { count, rows } = await SubMaterialBom.findAndCountAll({
    where: {
      is_deleted: 1,
      company_id,
      archive
    },
    attributes: ['id', 'product_id', 'part_id', 'archive', 'sort'],
    include: [
      { model: SubProductCode, as: 'product', attributes: ['id', 'product_name', 'product_code', 'drawing'], where: whereObj},
      { model: SubPartCode, as: 'part', attributes: ['id', 'part_name', 'part_code'] },
      {
        model: SubMaterialBomChild,
        as: 'children',
        attributes: ['id', 'material_bom_id', 'material_id', 'number', 'process_index'],
        include: [
          { model: SubMaterialCode, as: 'material', attributes: ['id', 'material_code', 'material_name', 'specification'] },
        ]
      }
    ],
    order: [
      ['product_id', 'DESC'],
      ['sort', 'ASC'],
      ['children', 'process_index', 'ASC']
    ],
    distinct: true,
    limit: parseInt(pageSize),
    offset
  })
  const totalPages = Math.ceil(count / pageSize)
  
  const fromData = rows.map(item => item.dataValues)
  // 返回所需信息
  res.json({ 
    data: formatArrayTime(fromData), 
    total: count, 
    totalPages, 
    currentPage: parseInt(page), 
    pageSize: parseInt(pageSize),
    code: 200 
  });
})

// 添加材料BOM
router.post('/material_bom', authMiddleware, async (req, res) => {
  const { product_id, part_id, archive, children, sort } = req.body;
  const { id: userId, company_id } = req.user;
  
  const material = await SubMaterialBom.create({
    product_id, part_id, archive, sort, company_id,
    user_id: userId
  })
  const childrens = children.map(e => ({ material_bom_id: material.id, company_id, user_id: userId, ...e }))
  await SubMaterialBomChild.bulkCreate(childrens);
  
  res.json({ message: '添加成功', code: 200 });
});

// 更新材料BOM
router.put('/material_bom', authMiddleware, async (req, res) => {
  const { product_id, part_id, children, archive, sort, id } = req.body;
  const { id: userId, company_id } = req.user;
  
  // 验证材料BOM是否存在
  const material = await SubMaterialBom.findByPk(id);
  if (!material) return res.json({ message: '材料BOM不存在', code: 401 });
  
  await SubMaterialBom.update({
    product_id, part_id, archive, sort, company_id,
    user_id: userId
  }, {
    where: { id }
  })

  // 查询当前所有旧子项
  const oldChildren = await SubMaterialBomChild.findAll({
    where: { material_bom_id: material.id },
  });
  const oldChildIds = oldChildren.map(child => child.id);
  
  if(children && children.length){
    const newChildIds = children.filter(child => child.id).map(child => child.id);
    // 计算需要删除的子项ID：旧有但不在新子项中的ID
    const idsToDelete = oldChildIds.filter(id => !newChildIds.includes(id));
    // 删除被前端移除的子项
    if (idsToDelete.length > 0) {
      await SubMaterialBomChild.destroy({
        where: { id: idsToDelete },
      });
    }
    // 批量新增/更新保留的子项
    const childrens = children.map(e => ({ material_bom_id: material.id, ...e }));
    await SubMaterialBomChild.bulkCreate(childrens, {
      updateOnDuplicate: ['material_bom_id', 'material_id', 'number', 'process_index'], // 按需调整更新字段
    });
  }
  res.json({ message: '修改成功', code: 200 });
});
// 添加材料BOM存档
router.put('/material_bom_archive', authMiddleware, async (req, res) => {
  const { archive, ids } = req.body;
  const updateResult = await SubMaterialBom.update({
    archive
  }, {
    where: { id: ids }
  })
  if(updateResult.length == 0) return res.json({ message: '数据不存在，或已被删除', code: 401})
  
  res.json({ message: '修改成功', code: 200 });
});
router.delete('/material_bom', authMiddleware, async (req, res) => {
  const { id } = req.query
  
  // 验证材料BOM是否存在
  const material = await SubMaterialBom.findByPk(id);
  if (!material) return res.json({ message: '材料BOM不存在', code: 401 });

  const updateResult = await SubMaterialBom.update({
    is_deleted: 0
  }, {
    where: { id }
  })
  
  res.json({ message: '删除成功', code: 200 });
})


// 获取工艺BOM信息表
router.get('/process_bom', authMiddleware, async (req, res) => {
  const { page = 1, pageSize = 10, archive, product_code, product_name, drawing } = req.query;
  const offset = (page - 1) * pageSize;
  const { company_id } = req.user;
  
  const whereObj = {}
  if(product_code) whereObj.product_code = { [Op.like]: `%${product_code}%` }
  if(product_name) whereObj.product_name = { [Op.like]: `%${product_name}%` }
  if(drawing) whereObj.drawing = { [Op.like]: `%${drawing}%` }
  
  try {
    const { count, rows } = await SubProcessBom.findAndCountAll({
      where: {
        is_deleted: 1,
        company_id,
        archive
      },
      attributes: ['id', 'archive', 'product_id', 'part_id', 'sort'],
      include: [
        { model: SubProductCode, as: 'product', attributes: ['id', 'product_name', 'product_code', 'drawing'], where: whereObj },
        { model: SubPartCode, as: 'part', attributes: ['id', 'part_name', 'part_code'] },
        {
          model: SubProcessBomChild,
          as: 'children',
          attributes: ['id', 'process_bom_id', 'process_id', 'equipment_id', 'process_index', 'time', 'price', 'points'],
          include: [
            { model: SubProcessCode, as: 'process', attributes: ['id', 'process_code', 'process_name'] },
            {
              model: SubEquipmentCode,
              as: 'equipment',
              attributes: ['id', 'equipment_code', 'equipment_name'],
              include: [
                { model: SubProcessCycle, as: 'cycle' }
              ]
            }
          ]
        }
      ],
      order: [
        ['product_id', 'DESC'],
        ['sort', 'ASC'],
        ['children', 'process_index', 'ASC'],
      ],
      distinct: true,
      limit: parseInt(pageSize),
      offset
    })
    const totalPages = Math.ceil(count / pageSize)
    const fromData = rows.map(item => item.dataValues)

    // 返回所需信息
    res.json({ 
      data: formatArrayTime(fromData), 
      total: count, 
      totalPages, 
      currentPage: parseInt(page), 
      pageSize: parseInt(pageSize),
      code: 200 
    });
  } catch (error) {
    console.log(error);
  }
})
// 添加工艺BOM
router.post('/process_bom', authMiddleware, async (req, res) => {
  const { product_id, part_id, archive, sort, children } = req.body;
  const { id: userId, company_id } = req.user;
  
  const process = await SubProcessBom.create({
    product_id, part_id, archive, sort, company_id,
    user_id: userId
  })
  const childrens = children.map(e => ({
    company_id,
    process_bom_id: process.id,
    user_id: userId,
    ...e
  }))
  const bomChild = await SubProcessBomChild.bulkCreate(childrens);

  const updateData = [];
  for (const e of bomChild) {
    const data = e.toJSON();
    const qr_code = await MainDataService.generateAndUploadQrcode( `${BaseConfig.bomQrCode_url}?id=${data.id}&company_id=${company_id}` );
    updateData.push({
      id: data.id,
      qr_code
    });
  }
  
  if (updateData.length > 0) {
    await SubProcessBomChild.bulkCreate(updateData, {
      updateOnDuplicate: ['qr_code']
    });
  }

  res.json({ message: '添加成功', code: 200 });
});
// 更新工艺BOM
router.put('/process_bom', authMiddleware, async (req, res) => {
  const { product_id, part_id, archive, sort, id, children } = req.body;
  const { id: userId, company_id } = req.user;
  
  // 验证工艺BOM是否存在
  const process = await SubProcessBom.findByPk(id);
  if (!process) return res.json({ message: '工艺BOM不存在', code: 401 });
  
  await SubProcessBom.update({
    product_id, part_id, archive, sort, company_id,
    user_id: userId
  }, {
    where: { id }
  })


  // 查询当前所有旧子项
  const oldChildren = await SubProcessBomChild.findAll({
    where: { process_bom_id: process.id },
    attributes: ['id', 'qr_code'],
  });
  const oldChildIds = oldChildren.map(child => child.id);

  if(children && children.length){
    const newChildIds = children.filter(child => child.id).map(child => child.id);
    // 计算需要删除的子项ID：旧有但不在新子项中的ID
    const idsToDelete = oldChildIds.filter(id => !newChildIds.includes(id));
    // 获取已被前端删除的旧数据
    if(idsToDelete.length > 0){
      const oldQrCodeItem = await SubProcessBomChild.findAll({
        where: { id: idsToDelete },
        attributes: ['id', 'qr_code']
      });
      // 提取所有非空的二维码URL
      const qrCodeUrls = oldQrCodeItem.filter(child => child.qr_code);
      if (qrCodeUrls.length > 0){
        // 从URL中提取七牛云文件key
        const qiniuKeys = qrCodeUrls.map(item => {
          const data = item.toJSON()
          const urlObj = new URL(data.qr_code);
          return urlObj.pathname.substring(1); // 去除开头的斜杠
        })
        try {
          // 调用批量删除接口
          await MainDataService.batchRemoveQiniuFiles(qiniuKeys);
        } catch (error) {
          // 这里可以根据业务需求决定是否中断操作或继续
          return res.json({ message: '服务器出错，请联系管理员', code: 401 });
        }
      }
      // 删除被前端移除的子项
      await SubProcessBomChild.destroy({
        where: { id: idsToDelete },
      });
    }
    
    const childrens = children.map(e => {
      if(!e.process_bom_id){
        e.process_bom_id = process.id,
        e.company_id = company_id
      }
      return e
    });
    // 批量新增/更新保留的子项
    await SubProcessBomChild.bulkCreate(childrens, {
      updateOnDuplicate: ['process_bom_id', 'process_id', 'equipment_id', 'process_index', 'time', 'price', 'points', 'company_id', 'notice_id', "user_id", 'notice'], // 按需调整更新字段
    });
    // 更新数据后重新获取数据
    const newChildrenList = await SubProcessBomChild.findAll({
      where: { process_bom_id: process.id },
      attributes: ['id', 'qr_code']
    });
    // 新增的子项需要生成二维码（判断是否有id，没有id的是新增的）
    const newChildren = newChildrenList.filter(child => !child.qr_code);
    // 生成新子项的二维码
    const updateData = [];
    for (const e of newChildren) {
      const data = e.toJSON();
      const qr_code = await MainDataService.generateAndUploadQrcode( `${BaseConfig.bomQrCode_url}?id=${data.id}&company_id=${company_id}` );
      updateData.push({
        id: data.id,
        qr_code
      });
    }
    if (updateData.length > 0) {
      await SubProcessBomChild.bulkCreate(updateData, {
        updateOnDuplicate: ['qr_code']
      });
    }
  }else {
    // 如果没有子项，删除所有旧子项
    if (oldChildIds.length > 0) {
      await SubProcessBomChild.destroy({
        where: { id: oldChildIds },
      });
    }
  }

  res.json({ message: '修改成功', code: 200 });
});
// 添加工艺BOM存档
router.put('/process_bom_archive', authMiddleware, async (req, res) => {
  const { archive, ids } = req.body;
  const updateResult = await SubProcessBom.update({
    archive
  }, {
    where: {
      id: ids
    }
  })
  if(updateResult.length == 0) return res.json({ message: '数据不存在，或已被删除', code: 401})
  
  res.json({ message: '修改成功', code: 200 });
});
// 删除工艺BOM
router.delete('/process_bom', authMiddleware, async (req, res) => {
  const { id } = req.query
  
  // 验证工艺BOM是否存在
  const process = await SubProcessBom.findByPk(id);
  if (!process) return res.json({ message: '工艺BOM不存在', code: 401 });
  
  const updateResult = await SubProcessBom.update({
    is_deleted: 0
  }, {
    where: {
      id
    }
  })
  
  res.json({ message: '删除成功', code: 200 });
})


// 复制新增
router.post('/cope_bom', authMiddleware, async (req, res) => {
  const { id, type } = req.body;
  const { id: userId, company_id } = req.user;
  
  if(!(type == 'material' || type == 'process')) return res.json({ message: '类型错误，仅支持material或process', code: 401 });
  
  const configMap = {
    material: {
      mainModel: SubMaterialBom,
      childModel: SubMaterialBomChild,
      mainFields: ['product_id', 'part_id', 'archive'], // 主表需复制的字段
      childForeignKey: 'material_bom_id', // 子表外键字段
      childFields: ['material_id', 'number'] // 子表需复制的字段
    },
    process: {
      mainModel: SubProcessBom,
      childModel: SubProcessBomChild,
      mainFields: ['product_id', 'part_id', 'archive'],
      childForeignKey: 'process_bom_id',
      childFields: ['process_id', 'equipment_id', 'time', 'price', 'points']
    }
  };
  const { mainModel, childModel, mainFields, childForeignKey, childFields } = configMap[type];
  const originalBom = await mainModel.findByPk(id, {
    attributes: mainFields,
    include: [{ model: childModel, as: 'children', attributes: childFields }]
  });
  if (!originalBom) {
    return res.json({ message: `${type === 'material' ? '材料' : '工艺'}BOM不存在`, code: 404 });
  }
  const originalData = originalBom.toJSON();
  const mainData = {
    ...mainFields.reduce((obj, key) => ({ ...obj, [key]: originalData[key] }), {}),
    archive: 0,
    sort: 0,
    company_id,
    user_id: userId
  };
  const newMainBom = await mainModel.create(mainData);
  const childDataList = originalData.children.map(child => ({
    [childForeignKey]: newMainBom.id,
    ...childFields.reduce((obj, key) => ({ ...obj, [key]: child[key] }), {})
  }));

  await childModel.bulkCreate(childDataList);
  
  return res.json({ message: '复制成功', code: 200 })
})

module.exports = router; 